MANAN SINGH — LEAD GENERATION WEBSITE

Files:
- index.html: complete responsive website
- assets/: the five videos you uploaded, copied into the website

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open the manan-agency-website folder.
3. Double-click index.html to open it in Chrome.

HOW TO PUBLISH FOR GOOGLE ADS AND META ADS
1. Upload the complete folder (index.html and assets folder together) to a static website host such as Netlify, Cloudflare Pages, or GitHub Pages.
2. Do not upload only index.html; the videos are required in the assets folder.
3. Use a public HTTPS website URL in your ads.
4. Before publishing ads, test every video and contact link on mobile and desktop.
5. Add Google Ads conversion tracking and Meta Pixel after the website is published. No tracking IDs have been added because your account IDs were not provided.

IMPORTANT CUSTOMISATION NOTES
- The contact details were populated from details previously provided by you. Verify the phone number, email and Instagram URL before publishing.
- The portfolio descriptions are descriptive placeholders based on the supplied clips; add client names, case studies, and results only if accurate and you have permission.
- The contact form prepares an enquiry in WhatsApp. It does not save leads in a database.
- The moving-forward road video is used as the intro/hero video as requested.
